import Flickity from 'flickity';

// Make available globally
window.Flickity = Flickity;
